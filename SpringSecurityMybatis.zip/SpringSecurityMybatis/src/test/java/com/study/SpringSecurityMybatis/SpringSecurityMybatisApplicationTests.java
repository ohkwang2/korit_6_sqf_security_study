package com.study.SpringSecurityMybatis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityMybatisApplicationTests {

	@Test
	void contextLoads() {
	}

}
